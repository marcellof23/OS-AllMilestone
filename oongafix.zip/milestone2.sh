dd if=/dev/zero of=./output/map.img bs=512 count=1
dd if=/dev/zero of=./output/files.img bs=512 count=2
dd if=/dev/zero of=./output/sectors.img bs=512 count=1
